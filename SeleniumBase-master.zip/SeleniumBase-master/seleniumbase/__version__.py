# seleniumbase package
__version__ = "4.39.1"
