from seleniumbase import BaseCase
BaseCase.main(__name__, __file__)


class NullTests(BaseCase):
    def test_null(self):
        pass
