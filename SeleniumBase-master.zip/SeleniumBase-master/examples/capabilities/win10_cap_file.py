# Desired capabilities example file for Windows 10 Grid nodes

capabilities = {
    "platformName": "WIN10",
    "browserVersion": "latest",
}
