``test_login.py::SwagLabsLoginTests::test_swag_labs_login``
---
| # | Step Description | Expected Result |
| - | ---------------- | --------------- |
| 1 | Log in to https://www.saucedemo.com with ``standard_user``. | Login was successful. |
| 2 | Log out from the website. | Logout was successful. |
